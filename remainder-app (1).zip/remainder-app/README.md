# Simple TodoList using React Native
<p>
  <a href="https://www.youtube.com/playlist?list=PLYBvEAka-q1hJuwRPYQPlEBBRm7_qGw_2">YouTube Tutorial Series</a>
</p>
<img src="./mockup.png" />
